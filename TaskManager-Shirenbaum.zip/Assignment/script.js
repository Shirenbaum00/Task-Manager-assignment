

//simplifying & defining variables 

const tasksUl = document.getElementById("tasksUl");
const form = document.getElementById("taskForm");
const descInput = document.getElementById("taskDescription");
const dateInput = document.getElementById("taskDueDate");
const dateToggle = document.getElementById("dateToggle");
const maxDateInput = document.getElementById("maxDate");
let maxDateFilter = "";



function getTodayStr() {
    var d = new Date();
    var y = d.getFullYear();
    var m = d.getMonth() + 1;
    var day = d.getDate();

    if (m < 10) m = "0" + m;
    if (day < 10) day = "0" + day;

    return y + "-" + m + "-" + day;
}


let tasks = getTasks()

//start the load

document.addEventListener("DOMContentLoaded", function () {
    tasks = getTasks();

    if (tasks.length === 0) {

        fetch("https://jsonplaceholder.typicode.com/todos?_limit=5")
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {
                var today = getTodayStr();


                for (var i = 0; i < data.length; i++) {
                    var todo = data[i];
                    tasks.push({
                        text: todo.title,
                        dueDate: today,
                        completed: todo.completed
                    });
                }

                saveTasks(tasks);
                renderTasks();
            })
            .catch(function (err) {
                console.log("API error:", err);
                renderTasks();
            });
    } else {

        renderTasks();
    }
});


//create new task objects

form.addEventListener("submit", function (event) {
    event.preventDefault();

    const newTask = {
        text: descInput.value,
        dueDate: dateInput.value,
        completed: false
    };

    tasks.push(newTask);
    saveTasks(tasks);
    renderTasks(tasks);

    form.reset();
})


//begining states
let currentFilter = "all";
let dateAscending = true;

//render
function renderTasks() {
    tasksUl.innerHTML = "";

    var todayStr = getTodayStr();

    for (let i = 0; i < tasks.length; i++) {
        let task = tasks[i];

        // status filter nav
        if (currentFilter !== "all" && String(task.completed) !== currentFilter) {
            continue;
        }

        //date filter
        if (maxDateFilter !== "" && task.dueDate > maxDateFilter) {
            continue;
        }

        // overdue tasks
        let overdueClass = "";
        let overdueText = "";
        if (task.completed === false && task.dueDate && task.dueDate < todayStr) {
            overdueClass = "overdue";
            overdueText = " (overdue)";
        }

        let completedClass = task.completed ? "completed" : "";

        tasksUl.innerHTML += `<li class="listItem ${completedClass} ${overdueClass}">
            <p class="descriptionLi">${task.text}</p>
            <div class="taskData">
            <p class="deadlineLi">Due: ${task.dueDate}${overdueText}</p>
            <button class="isDoneButton" onclick="toggleTask(${i})">
                ${task.completed ? "Undo" : "Done"}
            </button>
            <i class="fa-solid fa-trash deleteBtn" onclick="deleteTask(${i})"></i>
            </div>
        </li>
        `;
    }
}




function toggleTask(index) {
    tasks[index].completed = !tasks[index].completed;
    saveTasks(tasks);
    renderTasks();
}

function deleteTask(index) {
    tasks.splice(index, 1);
    saveTasks(tasks);
    renderTasks();
}



//filtering

const filterButtons = document.querySelectorAll(".filterButton");

filterButtons.forEach(btn => {
    btn.addEventListener("click", () => {

        filterButtons.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");


        currentFilter = btn.dataset.completed;
        renderTasks();
    });
});

//sort by date

dateToggle.addEventListener("click", function () {
    maxDateInput.style.display = "inline-block";
    maxDateInput.focus();
    dateToggle.style.display = "none";
});

//user picks a date
maxDateInput.addEventListener("change", function () {
    maxDateFilter = maxDateInput.value;
    renderTasks();
});

maxDateInput.addEventListener("blur", function () {
    if (maxDateInput.value === "") {
        maxDateInput.style.display = "none";
        dateToggle.style.display = "inline-flex";
    }
});



//Local storage

function getTasks() {
    const LStasks = localStorage.getItem("tasks");
    if (LStasks) {
        return JSON.parse(LStasks);
    } else {
        return [];
    }
}

function saveTasks(tasks) {
    const jsonString = JSON.stringify(tasks);
    localStorage.setItem("tasks", jsonString);
}

